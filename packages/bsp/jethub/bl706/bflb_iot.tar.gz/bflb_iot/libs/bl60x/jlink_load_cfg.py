# -*- coding:utf-8 -*-

jlink_shake_hand_addr = "00417FFC"
jlink_data_addr = "00400000"
jlink_load_addr = "0040C000"
jlink_core_type = "Cortex-M4"
jlink_set_tif = 1
jlink_run_addr = "22010000"
