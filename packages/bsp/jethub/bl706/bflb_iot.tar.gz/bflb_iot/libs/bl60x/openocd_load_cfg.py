# -*- coding:utf-8 -*-

openocd_shake_hand_addr = "00417FFC"
openocd_data_addr = "00400000"
openocd_load_addr = "0040C000"
openocd_core_type = "Cortex-M4"
openocd_set_tif = 1
openocd_run_addr = "22010000"
