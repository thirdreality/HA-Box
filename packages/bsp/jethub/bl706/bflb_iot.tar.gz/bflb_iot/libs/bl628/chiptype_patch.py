# -*- coding: utf-8 -*-


def img_load_create_predata_before_run_img():
    return bytearray(0)
