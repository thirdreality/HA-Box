# -*- coding:utf-8 -*-

jlink_shake_hand_addr = "2204BBE8"
jlink_data_addr = "2204CC88"
jlink_load_addr = "22010000"
jlink_core_type = "RISC-V"
jlink_set_tif = 0
jlink_run_addr = "22010000"
