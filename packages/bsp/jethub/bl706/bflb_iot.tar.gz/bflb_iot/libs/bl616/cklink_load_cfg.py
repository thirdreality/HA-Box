# -*- coding:utf-8 -*-

cklink_shake_hand_addr = "2204BBEC"
cklink_data_addr = "2204CC88"
cklink_load_addr = "22010000"
cklink_core_type = "RISC-V"
cklink_set_tif = 0
cklink_run_addr = "22010000"
