# -*- coding:utf-8 -*-

custom_config_len = 208  # 0xD0
clock_start_pos = 100 + custom_config_len  # 308 0x134
bootcfg_start_pos = 120 + custom_config_len  # 328 0x148
bootcfg_len = 48
bootcpucfg_start_pos = bootcfg_start_pos + bootcfg_len  # 376 #0x178
bootcpucfg_len = 16
bootcpucfg_m0_index = 0
bootcpucfg_d0_index = 1
bootcpucfg_lp_index = 2

boot2_start_pos = bootcpucfg_start_pos + bootcpucfg_len * (bootcpucfg_m0_index + 1)  # 392 0x188
boot2_len = 8

flashcfg_table_start_pos = boot2_start_pos + boot2_len  # 400 0x190
flashcfg_table_len = 8

patch_on_read_start_pos = flashcfg_table_start_pos + flashcfg_table_len  # 408 0x198
patch_on_read_len = 24

patch_on_jump_start_pos = patch_on_read_start_pos + patch_on_read_len  # 432 0x1B0
patch_on_jump_len = 24

rsvd_start_pos = patch_on_jump_start_pos + patch_on_jump_len  #456 0x1C8
rsvd_len = 4

crc32_start_pos = rsvd_start_pos + rsvd_len  # 460 0x1CC

bootheader_len = crc32_start_pos + 4  # 464 0x1D0

bootheader_cfg_keys = {
    "custom_magic_code": {
        "offset": "0",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_crc32": {
        "offset": "4",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_vendor_id": {
        "offset": "8",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_version": {
        "offset": "12",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_vendor_boot_offset": {
        "offset": "16",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_vendor_boot_len": {
        "offset": "20",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_ecc_type": {
        "offset": "24",
        "pos": "0",
        "bitlen": "8"
    },
    "custom_aes_type": {
        "offset": "24",
        "pos": "8",
        "bitlen": "8"
    },
    "custom_rsvd2": {
        "offset": "24",
        "pos": "16",
        "bitlen": "16"
    },
    "custom_hash_0": {
        "offset": "28",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_hash_1": {
        "offset": "32",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_hash_2": {
        "offset": "36",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_hash_3": {
        "offset": "40",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_hash_4": {
        "offset": "44",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_hash_5": {
        "offset": "48",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_hash_6": {
        "offset": "52",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_hash_7": {
        "offset": "56",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_0": {
        "offset": "60",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_1": {
        "offset": "64",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_2": {
        "offset": "68",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_3": {
        "offset": "72",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_4": {
        "offset": "76",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_5": {
        "offset": "80",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_6": {
        "offset": "84",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_7": {
        "offset": "88",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_8": {
        "offset": "92",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_9": {
        "offset": "96",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_10": {
        "offset": "100",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_11": {
        "offset": "104",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_12": {
        "offset": "108",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_13": {
        "offset": "112",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_14": {
        "offset": "116",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_signature_15": {
        "offset": "120",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_0": {
        "offset": "124",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_1": {
        "offset": "128",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_2": {
        "offset": "132",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_3": {
        "offset": "136",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_4": {
        "offset": "140",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_5": {
        "offset": "144",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_6": {
        "offset": "148",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_7": {
        "offset": "152",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_8": {
        "offset": "156",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_9": {
        "offset": "160",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_10": {
        "offset": "164",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_11": {
        "offset": "168",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_12": {
        "offset": "172",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_13": {
        "offset": "176",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_14": {
        "offset": "180",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_pk_15": {
        "offset": "184",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_aes_iv_0": {
        "offset": "188",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_aes_iv_1": {
        "offset": "192",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_aes_iv_2": {
        "offset": "196",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_aes_iv_3": {
        "offset": "200",
        "pos": "0",
        "bitlen": "32"
    },
    "custom_rsvd4": {
        "offset": "204",
        "pos": "0",
        "bitlen": "32"
    },
    "magic_code": {
        "offset": str(int(custom_config_len) + 0),
        "pos": "0",
        "bitlen": "32"
    },
    "revision": {
        "offset": str(int(custom_config_len) + 4),
        "pos": "0",
        "bitlen": "32"
    },
    # flash cfg
    "flashcfg_magic_code": {
        "offset": str(int(custom_config_len) + 8),
        "pos": "0",
        "bitlen": "32"
    },
    "io_mode": {
        "offset": str(int(custom_config_len) + 12),
        "pos": "0",
        "bitlen": "8"
    },
    "cont_read_support": {
        "offset": str(int(custom_config_len) + 12),
        "pos": "8",
        "bitlen": "8"
    },
    "sfctrl_clk_delay": {
        "offset": str(int(custom_config_len) + 12),
        "pos": "16",
        "bitlen": "8"
    },
    "sfctrl_clk_invert": {
        "offset": str(int(custom_config_len) + 12),
        "pos": "24",
        "bitlen": "8"
    },
    "reset_en_cmd": {
        "offset": str(int(custom_config_len) + 16),
        "pos": "0",
        "bitlen": "8"
    },
    "reset_cmd": {
        "offset": str(int(custom_config_len) + 16),
        "pos": "8",
        "bitlen": "8"
    },
    "exit_contread_cmd": {
        "offset": str(int(custom_config_len) + 16),
        "pos": "16",
        "bitlen": "8"
    },
    "exit_contread_cmd_size": {
        "offset": str(int(custom_config_len) + 16),
        "pos": "24",
        "bitlen": "8"
    },
    "jedecid_cmd": {
        "offset": str(int(custom_config_len) + 20),
        "pos": "0",
        "bitlen": "8"
    },
    "jedecid_cmd_dmy_clk": {
        "offset": str(int(custom_config_len) + 20),
        "pos": "8",
        "bitlen": "8"
    },
    "enter_32bits_addr_cmd": {
        "offset": str(int(custom_config_len) + 20),
        "pos": "16",
        "bitlen": "8"
    },
    "exit_32bits_addr_clk": {
        "offset": str(int(custom_config_len) + 20),
        "pos": "24",
        "bitlen": "8"
    },
    "sector_size": {
        "offset": str(int(custom_config_len) + 24),
        "pos": "0",
        "bitlen": "8"
    },
    "mfg_id": {
        "offset": str(int(custom_config_len) + 24),
        "pos": "8",
        "bitlen": "8"
    },
    "page_size": {
        "offset": str(int(custom_config_len) + 24),
        "pos": "16",
        "bitlen": "16"
    },
    "chip_erase_cmd": {
        "offset": str(int(custom_config_len) + 28),
        "pos": "0",
        "bitlen": "8"
    },
    "sector_erase_cmd": {
        "offset": str(int(custom_config_len) + 28),
        "pos": "8",
        "bitlen": "8"
    },
    "blk32k_erase_cmd": {
        "offset": str(int(custom_config_len) + 28),
        "pos": "16",
        "bitlen": "8"
    },
    "blk64k_erase_cmd": {
        "offset": str(int(custom_config_len) + 28),
        "pos": "24",
        "bitlen": "8"
    },
    "write_enable_cmd": {
        "offset": str(int(custom_config_len) + 32),
        "pos": "0",
        "bitlen": "8"
    },
    "page_prog_cmd": {
        "offset": str(int(custom_config_len) + 32),
        "pos": "8",
        "bitlen": "8"
    },
    "qpage_prog_cmd": {
        "offset": str(int(custom_config_len) + 32),
        "pos": "16",
        "bitlen": "8"
    },
    "qual_page_prog_addr_mode": {
        "offset": str(int(custom_config_len) + 32),
        "pos": "24",
        "bitlen": "8"
    },
    "fast_read_cmd": {
        "offset": str(int(custom_config_len) + 36),
        "pos": "0",
        "bitlen": "8"
    },
    "fast_read_dmy_clk": {
        "offset": str(int(custom_config_len) + 36),
        "pos": "8",
        "bitlen": "8"
    },
    "qpi_fast_read_cmd": {
        "offset": str(int(custom_config_len) + 36),
        "pos": "16",
        "bitlen": "8"
    },
    "qpi_fast_read_dmy_clk": {
        "offset": str(int(custom_config_len) + 36),
        "pos": "24",
        "bitlen": "8"
    },
    "fast_read_do_cmd": {
        "offset": str(int(custom_config_len) + 40),
        "pos": "0",
        "bitlen": "8"
    },
    "fast_read_do_dmy_clk": {
        "offset": str(int(custom_config_len) + 40),
        "pos": "8",
        "bitlen": "8"
    },
    "fast_read_dio_cmd": {
        "offset": str(int(custom_config_len) + 40),
        "pos": "16",
        "bitlen": "8"
    },
    "fast_read_dio_dmy_clk": {
        "offset": str(int(custom_config_len) + 40),
        "pos": "24",
        "bitlen": "8"
    },
    "fast_read_qo_cmd": {
        "offset": str(int(custom_config_len) + 44),
        "pos": "0",
        "bitlen": "8"
    },
    "fast_read_qo_dmy_clk": {
        "offset": str(int(custom_config_len) + 44),
        "pos": "8",
        "bitlen": "8"
    },
    "fast_read_qio_cmd": {
        "offset": str(int(custom_config_len) + 44),
        "pos": "16",
        "bitlen": "8"
    },
    "fast_read_qio_dmy_clk": {
        "offset": str(int(custom_config_len) + 44),
        "pos": "24",
        "bitlen": "8"
    },
    "qpi_fast_read_qio_cmd": {
        "offset": str(int(custom_config_len) + 48),
        "pos": "0",
        "bitlen": "8"
    },
    "qpi_fast_read_qio_dmy_clk": {
        "offset": str(int(custom_config_len) + 48),
        "pos": "8",
        "bitlen": "8"
    },
    "qpi_page_prog_cmd": {
        "offset": str(int(custom_config_len) + 48),
        "pos": "16",
        "bitlen": "8"
    },
    "write_vreg_enable_cmd": {
        "offset": str(int(custom_config_len) + 48),
        "pos": "24",
        "bitlen": "8"
    },
    "wel_reg_index": {
        "offset": str(int(custom_config_len) + 52),
        "pos": "0",
        "bitlen": "8"
    },
    "qe_reg_index": {
        "offset": str(int(custom_config_len) + 52),
        "pos": "8",
        "bitlen": "8"
    },
    "busy_reg_index": {
        "offset": str(int(custom_config_len) + 52),
        "pos": "16",
        "bitlen": "8"
    },
    "wel_bit_pos": {
        "offset": str(int(custom_config_len) + 52),
        "pos": "24",
        "bitlen": "8"
    },
    "qe_bit_pos": {
        "offset": str(int(custom_config_len) + 56),
        "pos": "0",
        "bitlen": "8"
    },
    "busy_bit_pos": {
        "offset": str(int(custom_config_len) + 56),
        "pos": "8",
        "bitlen": "8"
    },
    "wel_reg_write_len": {
        "offset": str(int(custom_config_len) + 56),
        "pos": "16",
        "bitlen": "8"
    },
    "wel_reg_read_len": {
        "offset": str(int(custom_config_len) + 56),
        "pos": "24",
        "bitlen": "8"
    },
    "qe_reg_write_len": {
        "offset": str(int(custom_config_len) + 60),
        "pos": "0",
        "bitlen": "8"
    },
    "qe_reg_read_len": {
        "offset": str(int(custom_config_len) + 60),
        "pos": "8",
        "bitlen": "8"
    },
    "release_power_down": {
        "offset": str(int(custom_config_len) + 60),
        "pos": "16",
        "bitlen": "8"
    },
    "busy_reg_read_len": {
        "offset": str(int(custom_config_len) + 60),
        "pos": "24",
        "bitlen": "8"
    },
    "reg_read_cmd0": {
        "offset": str(int(custom_config_len) + 64),
        "pos": "0",
        "bitlen": "8"
    },
    "reg_read_cmd1": {
        "offset": str(int(custom_config_len) + 64),
        "pos": "8",
        "bitlen": "8"
    },
    "reg_write_cmd0": {
        "offset": str(int(custom_config_len) + 68),
        "pos": "0",
        "bitlen": "8"
    },
    "reg_write_cmd1": {
        "offset": str(int(custom_config_len) + 68),
        "pos": "8",
        "bitlen": "8"
    },
    "enter_qpi_cmd": {
        "offset": str(int(custom_config_len) + 72),
        "pos": "0",
        "bitlen": "8"
    },
    "exit_qpi_cmd": {
        "offset": str(int(custom_config_len) + 72),
        "pos": "8",
        "bitlen": "8"
    },
    "cont_read_code": {
        "offset": str(int(custom_config_len) + 72),
        "pos": "16",
        "bitlen": "8"
    },
    "cont_read_exit_code": {
        "offset": str(int(custom_config_len) + 72),
        "pos": "24",
        "bitlen": "8"
    },
    "burst_wrap_cmd": {
        "offset": str(int(custom_config_len) + 76),
        "pos": "0",
        "bitlen": "8"
    },
    "burst_wrap_dmy_clk": {
        "offset": str(int(custom_config_len) + 76),
        "pos": "8",
        "bitlen": "8"
    },
    "burst_wrap_data_mode": {
        "offset": str(int(custom_config_len) + 76),
        "pos": "16",
        "bitlen": "8"
    },
    "burst_wrap_code": {
        "offset": str(int(custom_config_len) + 76),
        "pos": "24",
        "bitlen": "8"
    },
    "de_burst_wrap_cmd": {
        "offset": str(int(custom_config_len) + 80),
        "pos": "0",
        "bitlen": "8"
    },
    "de_burst_wrap_cmd_dmy_clk": {
        "offset": str(int(custom_config_len) + 80),
        "pos": "8",
        "bitlen": "8"
    },
    "de_burst_wrap_code_mode": {
        "offset": str(int(custom_config_len) + 80),
        "pos": "16",
        "bitlen": "8"
    },
    "de_burst_wrap_code": {
        "offset": str(int(custom_config_len) + 80),
        "pos": "24",
        "bitlen": "8"
    },
    "sector_erase_time": {
        "offset": str(int(custom_config_len) + 84),
        "pos": "0",
        "bitlen": "16"
    },
    "blk32k_erase_time": {
        "offset": str(int(custom_config_len) + 84),
        "pos": "16",
        "bitlen": "16"
    },
    "blk64k_erase_time": {
        "offset": str(int(custom_config_len) + 88),
        "pos": "0",
        "bitlen": "16"
    },
    "page_prog_time": {
        "offset": str(int(custom_config_len) + 88),
        "pos": "16",
        "bitlen": "16"
    },
    "chip_erase_time": {
        "offset": str(int(custom_config_len) + 92),
        "pos": "0",
        "bitlen": "16"
    },
    "power_down_delay": {
        "offset": str(int(custom_config_len) + 92),
        "pos": "16",
        "bitlen": "8"
    },
    "qe_data": {
        "offset": str(int(custom_config_len) + 92),
        "pos": "24",
        "bitlen": "8"
    },
    "flashcfg_crc32": {
        "offset": str(int(custom_config_len) + 96),
        "pos": "0",
        "bitlen": "32"
    },
    # clk cfg
    # clock start=100
    "clkcfg_magic_code": {
        "offset": str(int(clock_start_pos) + 0),
        "pos": "0",
        "bitlen": "32"
    },
    "xtal_type": {
        "offset": str(int(clock_start_pos) + 4),
        "pos": "0",
        "bitlen": "8"
    },
    "mcu_clk": {
        "offset": str(int(clock_start_pos) + 4),
        "pos": "8",
        "bitlen": "8"
    },
    "mcu_clk_div": {
        "offset": str(int(clock_start_pos) + 4),
        "pos": "16",
        "bitlen": "8"
    },
    "mcu_bclk_div": {
        "offset": str(int(clock_start_pos) + 4),
        "pos": "24",
        "bitlen": "8"
    },
    "mcu_pbclk_div": {
        "offset": str(int(clock_start_pos) + 8),
        "pos": "0",
        "bitlen": "8"
    },
    "emi_clk": {
        "offset": str(int(clock_start_pos) + 8),
        "pos": "8",
        "bitlen": "8"
    },
    "emi_clk_div": {
        "offset": str(int(clock_start_pos) + 8),
        "pos": "16",
        "bitlen": "8"
    },
    "flash_clk_type": {
        "offset": str(int(clock_start_pos) + 8),
        "pos": "24",
        "bitlen": "8"
    },
    "flash_clk_div": {
        "offset": str(int(clock_start_pos) + 12),
        "pos": "0",
        "bitlen": "8"
    },
    "wifipll_pu": {
        "offset": str(int(clock_start_pos) + 12),
        "pos": "8",
        "bitlen": "8"
    },
    "aupll_pu": {
        "offset": str(int(clock_start_pos) + 12),
        "pos": "16",
        "bitlen": "8"
    },
    "rsvd0": {
        "offset": str(int(clock_start_pos) + 12),
        "pos": "24",
        "bitlen": "8"
    },
    "clkcfg_crc32": {
        "offset": str(int(clock_start_pos) + 16),
        "pos": "0",
        "bitlen": "32"
    },
    # bootcfg
    "sign": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "0",
        "bitlen": "2"
    },
    "encrypt_type": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "2",
        "bitlen": "2"
    },
    "key_sel": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "4",
        "bitlen": "2"
    },
    "xts_mode": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "6",
        "bitlen": "1"
    },
    "aes_region_lock": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "7",
        "bitlen": "1"
    },
    "no_segment": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "8",
        "bitlen": "1"
    },
    "boot2_enable": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "9",
        "bitlen": "1"
    },
    "boot2_rollback": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "10",
        "bitlen": "1"
    },
    "cpu_master_id": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "11",
        "bitlen": "4"
    },
    "notload_in_bootrom": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "15",
        "bitlen": "1"
    },
    "crc_ignore": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "16",
        "bitlen": "1"
    },
    "hash_ignore": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "17",
        "bitlen": "1"
    },
    "power_on_mm": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "18",
        "bitlen": "1"
    },
    "em_sel": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "19",
        "bitlen": "3"
    },
    "cmds_en": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "22",
        "bitlen": "1"
    },
    "cmds_wrap_mode": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "23",
        "bitlen": "2"
    },
    "cmds_wrap_len": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "25",
        "bitlen": "4"
    },
    "icache_invalid": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "29",
        "bitlen": "1"
    },
    "dcache_invalid": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "30",
        "bitlen": "1"
    },
    "fpga_halt_release": {
        "offset": str(int(bootcfg_start_pos) + 0),
        "pos": "31",
        "bitlen": "1"
    },
    # flash controller offset
    "group_image_offset": {
        "offset": str(int(bootcfg_start_pos) + 4),
        "pos": "0",
        "bitlen": "32"
    },
    "aes_region_len": {
        "offset": str(int(bootcfg_start_pos) + 8),
        "pos": "0",
        "bitlen": "32"
    },
    # total image len or segment count
    "img_len_cnt": {
        "offset": str(int(bootcfg_start_pos) + 12),
        "pos": "0",
        "bitlen": "32"
    },
    # img hash
    "hash_0": {
        "offset": str(int(bootcfg_start_pos) + 16),
        "pos": "0",
        "bitlen": "32"
    },
    "hash_1": {
        "offset": str(int(bootcfg_start_pos) + 20),
        "pos": "0",
        "bitlen": "32"
    },
    "hash_2": {
        "offset": str(int(bootcfg_start_pos) + 24),
        "pos": "0",
        "bitlen": "32"
    },
    "hash_3": {
        "offset": str(int(bootcfg_start_pos) + 28),
        "pos": "0",
        "bitlen": "32"
    },
    "hash_4": {
        "offset": str(int(bootcfg_start_pos) + 32),
        "pos": "0",
        "bitlen": "32"
    },
    "hash_5": {
        "offset": str(int(bootcfg_start_pos) + 36),
        "pos": "0",
        "bitlen": "32"
    },
    "hash_6": {
        "offset": str(int(bootcfg_start_pos) + 40),
        "pos": "0",
        "bitlen": "32"
    },
    "hash_7": {
        "offset": str(int(bootcfg_start_pos) + 44),
        "pos": "0",
        "bitlen": "32"
    },
    # boot cpu m0 config
    "m0_config_enable": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 0),
        "pos": "0",
        "bitlen": "8"
    },
    "m0_halt_cpu": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 0),
        "pos": "8",
        "bitlen": "8"
    },
    "m0_cache_enable": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 0),
        "pos": "16",
        "bitlen": "1"
    },
    "m0_cache_wa": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 0),
        "pos": "17",
        "bitlen": "1"
    },
    "m0_cache_wb": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 0),
        "pos": "18",
        "bitlen": "1"
    },
    "m0_cache_wt": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 0),
        "pos": "19",
        "bitlen": "1"
    },
    "m0_cache_way_dis": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 0),
        "pos": "20",
        "bitlen": "4"
    },
    "m0_reserved": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 0),
        "pos": "24",
        "bitlen": "8"
    },
    "m0_image_address_offset": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 4),
        "pos": "0",
        "bitlen": "32"
    },
    "m0_boot_entry": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 8),
        "pos": "0",
        "bitlen": "32"
    },
    "m0_msp_val": {
        "offset": str(int(bootcpucfg_start_pos + bootcpucfg_len * bootcpucfg_m0_index) + 12),
        "pos": "0",
        "bitlen": "32"
    },
    # boot2 config
    "boot2_pt_table_0": {
        "offset": str(int(boot2_start_pos) + 0),
        "pos": "0",
        "bitlen": "32"
    },
    "boot2_pt_table_1": {
        "offset": str(int(boot2_start_pos) + 4),
        "pos": "0",
        "bitlen": "32"
    },
    # flash config table
    "flashCfgTableAddr": {
        "offset": str(int(flashcfg_table_start_pos) + 0),
        "pos": "0",
        "bitlen": "32"
    },
    "flashCfgTableLen": {
        "offset": str(int(flashcfg_table_start_pos) + 4),
        "pos": "0",
        "bitlen": "32"
    },
    # patch config
    "patch_read_addr0": {
        "offset": str(int(patch_on_read_start_pos) + 0),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_read_value0": {
        "offset": str(int(patch_on_read_start_pos) + 4),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_read_addr1": {
        "offset": str(int(patch_on_read_start_pos) + 8),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_read_value1": {
        "offset": str(int(patch_on_read_start_pos) + 12),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_read_addr2": {
        "offset": str(int(patch_on_read_start_pos) + 16),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_read_value2": {
        "offset": str(int(patch_on_read_start_pos) + 20),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_jump_addr0": {
        "offset": str(int(patch_on_jump_start_pos) + 0),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_jump_value0": {
        "offset": str(int(patch_on_jump_start_pos) + 4),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_jump_addr1": {
        "offset": str(int(patch_on_jump_start_pos) + 8),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_jump_value1": {
        "offset": str(int(patch_on_jump_start_pos) + 12),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_jump_addr2": {
        "offset": str(int(patch_on_jump_start_pos) + 16),
        "pos": "0",
        "bitlen": "32"
    },
    "patch_jump_value2": {
        "offset": str(int(patch_on_jump_start_pos) + 20),
        "pos": "0",
        "bitlen": "32"
    },
    # rsvd config
    "reserved": {
        "offset": str(int(rsvd_start_pos) + 0),
        "pos": "0",
        "bitlen": "32"
    },
    "crc32": {
        "offset": str(int(crc32_start_pos) + 0),
        "pos": "0",
        "bitlen": "32"
    },
}
